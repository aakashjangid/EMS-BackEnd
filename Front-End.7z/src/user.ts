import { Time } from "@angular/common";

export class User {
    'id': number;
    'name': string;
    'email': string;
    'contact': string;
    'orgName': string;
    'regDate': Date;
    'regTime': Time;
    'status': number;
    'role': number;
    'userImage': string;
}