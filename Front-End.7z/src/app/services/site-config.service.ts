import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { SiteConfigModel } from '../models/siteConfigModel';

@Injectable({
  providedIn: 'root'
})
export class SiteConfigService {

  url: string = "http://localhost:8080/ems";

  constructor(private http: HttpClient) { }

  addDevice(siteConfigModel){
    return this.http.post(this.url+"/sites/addDevice", siteConfigModel).pipe();
  }

  getAllSitesOfUser(userId){
    return this.http.get(this.url+"/sites/getAllSitesOfUser/"+userId).pipe();
  }

  addParameter(parameter){
    return this.http.post(this.url+"/sites/addParameter", parameter).pipe();
  }

}