import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  url: string = "http://localhost:8080/ems";

  constructor(private http: HttpClient) { }

  getAllRegisteredOrganizations(){
    return this.http.get(this.url+"/users/getAllRegisteredOrganizations").pipe();
  }
}
