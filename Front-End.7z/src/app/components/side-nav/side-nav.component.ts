import { Component, OnInit } from '@angular/core';
import { SiteConfigService } from '../../services/site-config.service';
import { Site } from '../../models/site';
import { Router } from '@angular/router';

@Component({
  selector: 'app-side-nav',
  templateUrl: './side-nav.component.html',
  styleUrls: ['./side-nav.component.css']
})
export class SideNavComponent implements OnInit {

  userId: any;
  sites: Site[];
  selectedSite: Site;

  constructor(private siteService: SiteConfigService, private router: Router) {
    // this.userId = localStorage.getItem('userId');
    this.userId = 1;
  }

  ngOnInit() {
    this.getAllSitesOfUser();
  }

  getAllSitesOfUser() {
    this.siteService.getAllSitesOfUser(this.userId).subscribe(
      data => {
        this.sites = data as any;
      },
      error => {
        console.log("Error in fetching site", error);
      }
    );
  }

  openSiteDetails(siteId) {
    for (let index = 0; index < this.sites.length; index++) {
      if (this.sites[index].siteId == siteId) {
        this.selectedSite = this.sites[index];
        break;
      }
    }
    localStorage.setItem('selectedSite', JSON.stringify(this.selectedSite));
    this.router.navigate(['/siteInfo']);
  }

}
