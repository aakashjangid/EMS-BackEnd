import { Component, OnInit, ViewChild } from '@angular/core';
import { Site } from '../../models/site';
import { Router } from '@angular/router';
import { MatPaginator, MatTableDataSource } from '@angular/material';
import { Parameter } from '../../models/parameter';
import { SiteConfigService } from '../../services/site-config.service';

@Component({
  selector: 'app-show-site-info',
  templateUrl: './show-site-info.component.html',
  styleUrls: ['./show-site-info.component.css']
})
export class ShowSiteInfoComponent implements OnInit {

  selectedSite: Site;
  dataSource;

  displayedColumns: string[] = ['Type', 'Label', 'Acronym', 'Measuring Unit', 'Operations'];

  label: string;
  acronym: string;
  type: string = "analog";
  measuringUnit: string;
  highValue: string;
  lowValue: string;
  highFault: string;
  lowFault: string;
  address: string;

  constructor(private router: Router, private siteConfigService: SiteConfigService) {
    if (!localStorage.getItem('selectedSite')) {
      this.router.navigate(['/home']);
    }
    this.selectedSite = JSON.parse(localStorage.getItem('selectedSite'));
    localStorage.removeItem('selectedSite');
  }

  ngOnInit() {
    this.dataSource = new MatTableDataSource<Parameter>(this.selectedSite.parameters);
  }

  changeType(value) {
    this.type = value;
  }

  addParameter(siteId) {
    let parameter = {
      'siteId': siteId,

      'label': this.label,
      'acronym': this.acronym,
      'type': this.type,
      'measuringUnit': this.measuringUnit,
      'highValue': this.highValue,
      'lowValue': this.lowValue,
      'highFault': this.highFault,
      'lowFault': this.lowFault,
      'address': this.address
    }
    this.siteConfigService.addParameter(parameter).subscribe(
      data => {
        this.dataSource = new MatTableDataSource<Parameter>(data as any);

      }, error => {
        console.log('Error in adding parameter', error);
      }
    );
  }
}
