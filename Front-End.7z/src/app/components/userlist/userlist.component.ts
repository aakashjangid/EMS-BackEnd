import { Component, OnInit } from '@angular/core';
import { User } from '../../../user';
import { UserService } from '../../services/user.service';
import { StorageService } from '../../services/storage.service';

@Component({
  selector: 'app-userlist',
  templateUrl: './userlist.component.html',
  styleUrls: ['./userlist.component.css']
})
export class UserlistComponent implements OnInit {

  users: User[] = [];
  loggedInUser: User;

  constructor(private userService: UserService, private storageService: StorageService) { 
    // this.loggedInUser = this.storageService.getLoggedInUser();
    // if(this.loggedInUser.role == 0){
    //   this.getAllRegisteredOrganizations();
    // }else if(this.loggedInUser.role ==1){

    // }else {

    // }
  }

  ngOnInit() {
    this.getAllRegisteredOrganizations();
  }

  getAllRegisteredOrganizations(){
    this.userService.getAllRegisteredOrganizations().subscribe(
      data =>{
        this.users = data as any;
      },
      error =>{
        console.log("Error in getAllRegisteredOrganizations", error);
      }
    );
  }

}
