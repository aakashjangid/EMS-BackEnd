import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-parameter',
  templateUrl: './new-parameter.component.html',
  styleUrls: ['./new-parameter.component.css']
})
export class NewParameterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
