import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SiteConfigModel } from '../../models/siteConfigModel';
import { SiteConfigService } from '../../services/site-config.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-site-config',
  templateUrl: './site-config.component.html',
  styleUrls: ['./site-config.component.css']
})
export class SiteConfigComponent implements OnInit {

  isLinear = false;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  thirdFormGroup: FormGroup;

  chosenAlert: number;

  userId: any;

  siteName: string;
  postURL: string;
  schemaURL: string;

  deviceName: string;
  deviceManuf: string;
  deviceModel: string;
  deviceAddress: string;

  label: string;
  acronym: string;
  type: string = "analog";
  measuringUnit: string;
  highValue: string;
  lowValue: string;
  highFault: string;
  lowFault: string;
  address: string;

  constructor(private _formBuilder: FormBuilder, private siteConfigService: SiteConfigService, private router: Router) {
    // this.userId = localStorage.getItem('userId');
    this.userId=1;
  }

  ngOnInit() {
    this.firstFormGroup = this._formBuilder.group({
      firstCtrl: ['', Validators.required]
    });
    this.secondFormGroup = this._formBuilder.group({
      secondCtrl: ['', Validators.required]
    });
    this.thirdFormGroup = this._formBuilder.group({
      thirdCtrl: ['', Validators.required]
    });
  }

  changeType(value) {
    this.type = value;
  }

  addDevice() {
    let siteConfigModel = {
      'userId': this.userId,
      'siteName': this.siteName,
      'postURL': this.postURL,
      'schemaURL': this.schemaURL,

      'deviceName': this.deviceName,
      'deviceManuf': this.deviceManuf,
      'deviceModel': this.deviceModel,
      'deviceAddress': this.deviceAddress,

      'label': this.label,
      'acronym': this.acronym,
      'type': this.type,
      'measuringUnit': this.measuringUnit,
      'highValue': this.highValue,
      'lowValue': this.lowValue,
      'highFault': this.highFault,
      'lowFault': this.lowFault,
      'address': this.address
    };
    this.siteConfigService.addDevice(siteConfigModel).subscribe(
      data => {
        this.router.navigate(['/home']);
      },
      error => {
        console.log('Error in adding device', error);
      }
    );
  }

}