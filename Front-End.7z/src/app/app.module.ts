import { BrowserModule } from '@angular/platform-browser';
import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatStepperModule} from '@angular/material/stepper';
import {MatInputModule} from '@angular/material/input';
import {MatSelectModule} from '@angular/material/select';
import {MatTableModule} from '@angular/material/table';

import { AppComponent } from './app.component';
import { UserlistComponent } from './components/userlist/userlist.component';

import { LocationStrategy, HashLocationStrategy } from '@angular/common';
import { HeaderComponent } from './components/header/header.component';
import { HomeComponent } from './components/home/home.component';
import { SideNavComponent } from './components/side-nav/side-nav.component';
import { SiteConfigComponent } from './components/site-config/site-config.component';
import { GeneralConfigComponent } from './components/general-config/general-config.component';
import { ShowSiteInfoComponent } from './components/show-site-info/show-site-info.component';
import { NewParameterComponent } from './components/new-parameter/new-parameter.component';

const appRoutes: Routes = [
  { path: 'list', component: UserlistComponent },
  { path: 'home', component: HomeComponent },
  { path: 'siteConfig', component: SiteConfigComponent },
  { path: 'siteInfo', component: ShowSiteInfoComponent },
  { path: '', redirectTo: '/home', pathMatch: 'full' }
];

@NgModule({
  declarations: [
    AppComponent,
    UserlistComponent,
    HeaderComponent,
    HomeComponent,
    SideNavComponent,
    SiteConfigComponent,
    GeneralConfigComponent,
    ShowSiteInfoComponent,
    NewParameterComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(appRoutes),
    BrowserAnimationsModule,
    MatStepperModule,
    ReactiveFormsModule,
    MatInputModule,
    MatSelectModule,
    MatTableModule
  ],
  providers: [{ provide: LocationStrategy, useClass: HashLocationStrategy }],
  bootstrap: [AppComponent],
  schemas: [NO_ERRORS_SCHEMA]
})
export class AppModule { }
