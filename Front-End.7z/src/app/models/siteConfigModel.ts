export interface SiteConfigModel {

    postURL: string;
    schemaURL: string;

    deviceName: string;
    deviceManuf: string;
    deviceModel: string;
    deviceAddress: string;

    label: string;
    acronym: string;
    type: string;
    measuringUnit: string;
    highValue: string;
    lowValue: string;
    highFault: string;
    lowFault: string;
    address: string;

}